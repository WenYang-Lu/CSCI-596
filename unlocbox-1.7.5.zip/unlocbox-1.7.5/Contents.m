%  Unlocbox - About this toolbox
%
%  Starting the toolbox
%    init_unlocbox      -  Initialize the UNLocBoX
%    close_unlocbox     -  Stop the UNLocBoX
%
%
%  For help, bug reports, suggestions etc. please send email to
%  unlocbox (at) groupes (dot) epfl (dot) ch
%
