plotengine='matlab'
author='Nathanael Perraudin'
version="1.1.97"
versionfile="unlocbox_version"
year="2014"

outputdir = '/tmp'

try:
    from conf_local import *
except:
    raise