addpath /Users/nati/work/git/toolbox/unlocbox
init_unlocbox;

addpath /Users/nati/work/git/toolbox/ltfat
ltfatstart;
