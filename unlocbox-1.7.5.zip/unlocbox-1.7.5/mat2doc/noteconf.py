notesdir = '~/work/svn/unlocbox-svn-note/'
notehtml = 'unlocboxphp/notes/'
