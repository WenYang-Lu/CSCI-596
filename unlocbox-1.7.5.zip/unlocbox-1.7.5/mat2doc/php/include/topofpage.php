<table style="height:100%; width:100%">
<tr>
<td valign="top" width="65%">
<h1>UNLocBoX</h1>
<h2>- Matlab convex optimization toolbox -</h2>
</td>
<td valign="middle">
<a href="/index.php"><img src="/include/unlocbox.png" alt="UnLocX Logo" height="70"></a>
</td>
</tr>
</table> 
