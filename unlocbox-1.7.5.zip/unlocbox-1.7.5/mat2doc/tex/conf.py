fext='.tex'
urlbase='https://epfl-lts2.github.io/unlocbox-html/doc'
urlext='html'
widthstr='50ex'
imagetype='eps'
includeoutput=False